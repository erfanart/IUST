package IUST.ControlApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControlAppApplication.class, args);
	}

}
