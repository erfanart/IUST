package IUST.ControlApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControlAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
